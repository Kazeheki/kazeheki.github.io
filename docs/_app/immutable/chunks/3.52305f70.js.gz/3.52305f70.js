import{default as t}from"../entry/contact-page.svelte.c00d3ab2.js";export{t as component};
