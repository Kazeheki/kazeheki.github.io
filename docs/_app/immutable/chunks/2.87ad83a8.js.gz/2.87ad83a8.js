import{default as t}from"../entry/_page.svelte.5045cca1.js";export{t as component};
