import{default as t}from"../entry/_error.svelte.a172faf2.js";export{t as component};
