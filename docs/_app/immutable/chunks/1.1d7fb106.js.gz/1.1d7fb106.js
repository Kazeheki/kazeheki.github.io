import{default as t}from"../entry/_error.svelte.61ea0614.js";export{t as component};
