import{default as t}from"../entry/_error.svelte.8818885d.js";export{t as component};
