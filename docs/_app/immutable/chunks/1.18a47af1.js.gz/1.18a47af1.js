import{default as t}from"../entry/_error.svelte.9760b030.js";export{t as component};
