import{default as t}from"../entry/_error.svelte.c9d32d6c.js";export{t as component};
