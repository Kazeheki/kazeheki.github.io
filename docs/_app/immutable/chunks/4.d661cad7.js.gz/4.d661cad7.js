import{default as t}from"../entry/skills-page.svelte.b1bb2f20.js";export{t as component};
