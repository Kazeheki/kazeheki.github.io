import{default as t}from"../entry/contact-page.svelte.3dac5476.js";export{t as component};
